#!/bin/bash

rm -rf jgproject
jg -tcl jasper.tcl &
